=== WP-Stats ===
Contributors: GamerZ
Donate link: http://lesterchan.net/wordpress
Tags: stat, stats, statistics, wp-stats, wp-stat, top, most, widget, popular, information
Requires at least: 2.8
Stable tag: 2.50

Display your WordPress blog statistics. Ranging from general total statistics, some of my plugins statistics and top 10 statistics.

== Description ==

All the information (general, changelog, installation, upgrade, usage) you need about this plugin can be found here: [WP-Stats Readme](http://lesterchan.net/wordpress/readme/wp-stats.html "WP-Stats Readme").
It is the exact same readme.html is included in the zip package.

== Development Blog ==

[GaMerZ WordPress Plugins Development Blog](http://lesterchan.net/wordpress/ "GaMerZ WordPress Plugins Development Blog")

== Installation ==

[WP-Stats Readme](http://lesterchan.net/wordpress/readme/wp-stats.html "WP-Stats Readme") (Installation Tab)

== Screenshots ==

[WP-Stats Screenshots](http://lesterchan.net/wordpress/screenshots/browse/wp-stats/ "WP-Stats Screenshots")

== Frequently Asked Questions ==

[WP-Stats Support Forums](http://forums.lesterchan.net/index.php?board=20.0 "WP-Stats Support Forums")
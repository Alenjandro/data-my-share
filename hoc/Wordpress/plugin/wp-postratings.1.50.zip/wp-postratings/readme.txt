=== WP-PostRatings ===
Contributors: GamerZ
Donate link: http://lesterchan.net/wordpress
Tags: ban, ratings, rating, postratings, postrating, vote, digg, ajax, post
Requires at least: 2.8
Stable tag: 1.50

Adds an AJAX rating system for your WordPress blog's post/page.

== Description ==

All the information (general, changelog, installation, upgrade, usage) you need about this plugin can be found here: [WP-PostRatings Readme](http://lesterchan.net/wordpress/readme/wp-postratings.html "WP-PostRatings Readme").
It is the exact same readme.html is included in the ZIP package.

== Development Blog ==

[GaMerZ WordPress Plugins Development Blog](http://lesterchan.net/wordpress/ "GaMerZ WordPress Plugins Development Blog")

== Installation ==

[WP-PostRatings Readme](http://lesterchan.net/wordpress/readme/wp-postratings.html "WP-PostRatings Readme") (Installation Tab)

== Screenshots ==

[WP-PostRatings Screenshots](http://lesterchan.net/wordpress/screenshots/browse/wp-postratings/ "WP-PostRatings Screenshots")

== Frequently Asked Questions ==

[WP-PostRatings Support Forums](http://forums.lesterchan.net/index.php?board=17.0 "WP-PostRatings Support Forums")

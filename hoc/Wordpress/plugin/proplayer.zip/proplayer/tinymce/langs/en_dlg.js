tinyMCE.addI18n('en.proPlayer',{
	title : 'Add Video by ProPlayer'
});

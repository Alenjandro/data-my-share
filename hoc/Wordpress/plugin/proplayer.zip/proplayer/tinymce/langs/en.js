tinyMCE.addI18n('en.proPlayer',{
	desc : 'Add video by using ProPlayer'
});

<?php if (!defined ('ABSPATH')) die (); ?><h2>Category Specific Permalinks</h2>
<table class="editform" width="100%" cellspacing="2" cellpadding="5">
	<tr>
		<th width="33%">URL base:</th>
		<td><input type="text" name="permalink" value="<?php echo htmlspecialchars ($permalink) ?>" style="width: 95%"/></td>
	</tr>
</table>
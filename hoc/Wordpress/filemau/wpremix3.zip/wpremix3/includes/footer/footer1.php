<!-- / id pageBody --></div>

<div id="footer">
<div class="footerInner">
<ul>
<li><a href="#"><img src="<?php bloginfo('template_url'); ?>/images/common/fnav_use.gif" alt="ご利用にあたって" /></a></li>
<li><a href="#"><img src="<?php bloginfo('template_url'); ?>/images/common/fnav_policy.gif" alt="個人情報保護方針" /></a></li>
<li><a href="#"><img src="<?php bloginfo('template_url'); ?>/images/common/fnav_sitemap.gif" alt="サイトマップ" /></a></li>
</ul>
<p><img src="<?php bloginfo('template_url'); ?>/images/common/txt_copyright.gif" alt="Copyright &copy; 2011 Nittetsu Plant Designing Corporation. All rights reserved." /></p>

<!-- / class footerInner --></div>
<!-- / id footer --></div>
<!-- / id layout --></div>
</body>
</html>
<form method="get" id="searchform" action="<?php bloginfo('home'); ?>">
	<input type="text" value="Search here..." name="s" class="s" onfocus="if (this.value == 'Search here...') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search here...';}"/>
	<input type="image" src="<?php bloginfo('template_url'); ?>/images/none.png" alt="" class="sgo"  />
</form>
 

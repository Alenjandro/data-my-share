<!-- NO sidebar -->
<style type="text/css">
#content { width:100%; }
#content .subcolumns, #sidebar .subcolumns { width:49%; }
#content .profile { width:49%; }
#content .showcase { width:49%; }
#content .showcase .scontent { width:74%; }
#content .profile2 { width:46%; }
#content .service { background: transparent; }
#content .helpline li { width:39%; }
#content .steps { width:31%; }
#content .pright { width:85%; }
#content .magazine { width:570px; }
#content .mcontent { width:520px; }
#content .productbox { width:760px; }
#content .gallery { margin-right:10px; }
#content h3 { clear:left; }
#content .fcontent { width:640px; }
#content .sitemap_list { width:250px; }
</style>

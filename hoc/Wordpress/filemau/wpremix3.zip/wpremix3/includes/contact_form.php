<!--<h5>Contact </h5>
<div class="contactform" id="c_form_2">
<?php
	// echo contact($_GET["page_id"]."#c_form_2");
?>
</div>-->
<a href="#" target="_blank"><img src="<?php bloginfo('template_url'); ?>/images/advt_468x60.png" alt="WP Remix"  /></a>

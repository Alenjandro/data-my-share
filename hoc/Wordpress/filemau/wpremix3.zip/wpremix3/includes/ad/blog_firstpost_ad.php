<div class="postads">
<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/advt_468x60.png" alt=""  border="0"  /></a> 
</div>

 

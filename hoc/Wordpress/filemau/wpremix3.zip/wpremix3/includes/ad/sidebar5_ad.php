<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/advt_234x60a.png" alt="" class="ads" ></a>
<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/advt_234x60b.png" alt="" class="ads" ></a>
<a href="#"><img src="<?php bloginfo('template_url'); ?>/images/advt_234x60c.png" alt="" class="ads" ></a>

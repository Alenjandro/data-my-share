<p class="pageTop"><a href="#layout"><img src="<?php bloginfo('template_url'); ?>/images/common/txt_pagetop.gif" alt="ページトップへ戻る" /></a></p>
<!-- / id pageBody --></div>

<div id="footer">
<div class="footerInner">
<ul>
<li><a href="<?php bloginfo('url'); ?>/guide/"><img src="<?php bloginfo('template_url'); ?>/images/common/fnav_use.gif" alt="ご利用にあたって" /></a></li>
<li><a href="<?php bloginfo('url'); ?>/privacy/"><img src="<?php bloginfo('template_url'); ?>/images/common/fnav_policy.gif" alt="個人情報保護方針" /></a></li>
<li><a href="<?php bloginfo('url'); ?>/risk/"><img src="<?php bloginfo('template_url'); ?>/images/common/fnav_risk.gif" alt="コーポレートリスク相談" /></a></li>
<li><a href="<?php bloginfo('url'); ?>/sitemap/"><img src="<?php bloginfo('template_url'); ?>/images/common/fnav_sitemap.gif" alt="サイトマップ" /></a></li>
</ul>
<p><img src="<?php bloginfo('template_url'); ?>/images/common/txt_copyright.gif" alt="Copyright &copy; 2011 Nittetsu Plant Designing Corporation. All rights reserved." /></p>

<!-- / class footerInner --></div>
<!-- / id footer --></div>
<!-- / id layout --></div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-20543483-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</body>
</html>
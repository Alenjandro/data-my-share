<div id="sidebar">
<dl class="lNav">
<dt><img src="/wp/wp-content/themes/wpremix3/images/recruit/ttl_recruit.gif" alt="採用情報 Recruit Information" /></dt>
<dd><ul>
<li><a href="http://www.npd.nsc-eng.co.jp/recruit/fresh/"><img src="/wp/wp-content/themes/wpremix3/images/recruit/lnav_grad_o.gif" alt="新卒採用" /></a>
<ul>
<li><a href="http://www.npd.nsc-eng.co.jp/recruit/fresh/guideline/"><img src="/wp/wp-content/themes/wpremix3/images/recruit/fresh/snav_guide.gif" alt="2012年度 新卒募集要項" class="imgover" /></a></li>
<li><a href="http://www.npd.nsc-eng.co.jp/recruit/fresh/rep/"><img src="/wp/wp-content/themes/wpremix3/images/recruit/fresh/snav_resources.gif" alt="採用担当者より" class="imgover" /></a></li>
<li><a href="http://www.npd.nsc-eng.co.jp/recruit/fresh/message/"><img src="/wp/wp-content/themes/wpremix3/images/recruit/fresh/snav_voice.gif" alt="先輩の声" class="imgover" /></a></li>
<li><a href="http://www.npd.nsc-eng.co.jp/recruit/fresh/flow/"><img src="/wp/wp-content/themes/wpremix3/images/recruit/fresh/snav_flow.gif" alt="採用の流れ" class="imgover" /></a></li>
<li><a href="http://www.npd.nsc-eng.co.jp/recruit/fresh/qa/"><img src="/wp/wp-content/themes/wpremix3/images/recruit/fresh/snav_qa.gif" alt="採用Q&amp;A" class="imgover" /></a></li>
<li><a href="http://www.npd.nsc-eng.co.jp/recruit/fresh/training/"><img src="/wp/wp-content/themes/wpremix3/images/recruit/fresh/snav_training.gif" alt="研修制度" class="imgover" /></a></li>
</ul>
</li>
<li><a href="http://www.npd.nsc-eng.co.jp/recruit/career/"><img src="/wp/wp-content/themes/wpremix3/images/recruit/lnav_midcareer.gif" alt="中途採用" class="imgover" /></a></li>
</ul></dd>
<!-- / class lNav --></dl>
<ul class="banner">
<li><a href="<?php bloginfo('url'); ?>/business/"><img src="<?php bloginfo('template_url'); ?>/images/common/bnr_work.jpg" alt="私たちの仕事
新日鉄エンジニアリンググループの設計部門を担っています。" class="imgover" /></a></li>
<li><a href="<?php bloginfo('url'); ?>/pdf/heisei23nen_slogans.pdf" target="_blank"><img src="<?php bloginfo('template_url'); ?>/images/common/bnr_future.jpg" alt="未来価値実現へ
確かな一歩、Active NPD！" class="imgover" /></a></li>
<li><a href="<?php bloginfo('url'); ?>/recruit/"><img src="<?php bloginfo('template_url'); ?>/images/common/bnr_design.jpg" alt="日鐵プラント設計では、若い力を求めています。" class="imgover" /></a></li>
</ul>

<p class="produced"><a href="https://job.rikunabi.com/2012/company/top/r866500091/?isc=r1rs00000101" target="_blank"><img src="<?php bloginfo('template_url'); ?>/images/recruit/img_produced.gif" alt="リクナビ2012
PRODUCED BY RECRUIT" class="imgover" /></a></p>
<!-- / id sidebar --></div>
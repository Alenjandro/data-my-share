<?php get_remix_header(); ?>
<p>ページがありません。</p>

<?php get_footer(); ?>

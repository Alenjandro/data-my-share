<div id="sidebar">
<dl class="lNav">
<dt><img src="<?php bloginfo('template_url'); ?>/images/company/ttl_company.gif" alt="企業情報 Company Information" /></dt>
<dd><ul>
<li id="lNavIdeal"><a href="<?php bloginfo('url'); ?>/company/ideal/"><img src="<?php bloginfo('template_url'); ?>/images/company/lnav_ideal.gif" alt="企業理念" class="imgover" /></a></li>
<li id="lNavMessage"><a href="<?php bloginfo('url'); ?>/company/message/"><img src="<?php bloginfo('template_url'); ?>/images/company/lnav_message_o.gif" alt="トップメッセージ" /></a></li>
<li id="lNavAbout"><a href="<?php bloginfo('url'); ?>/company/about/"><img src="<?php bloginfo('template_url'); ?>/images/company/lnav_about.gif" alt="会社概要" class="imgover" /></a></li>
<li id="lNavExecutive"><a href="<?php bloginfo('url'); ?>/company/executive/"><img src="<?php bloginfo('template_url'); ?>/images/company/lnav_executive.gif" alt="役員" class="imgover" /></a></li>
<li id="lNavChart"><a href="<?php bloginfo('url'); ?>/company/chart/"><img src="<?php bloginfo('template_url'); ?>/images/company/lnav_chart.gif" alt="組織図" class="imgover" /></a></li>
<li id="lNavHistory"><a href="<?php bloginfo('url'); ?>/company/history/"><img src="<?php bloginfo('template_url'); ?>/images/company/lnav_history.gif" alt="沿革" class="imgover" /></a></li>
<li id="lNavLicense"><a href="<?php bloginfo('url'); ?>/company/license/"><img src="<?php bloginfo('template_url'); ?>/images/company/lnav_license.gif" alt="主な国家資格保有者" class="imgover" /></a></li>
<li id="lNavAccess"><a href="<?php bloginfo('url'); ?>/company/access/"><img src="<?php bloginfo('template_url'); ?>/images/company/lnav_access.gif" alt="アクセス" class="imgover" /></a></li>
</ul></dd>
<!-- / class lNav --></dl>

<ul class="banner">
<li><a href="<?php bloginfo('url'); ?>/business/"><img src="<?php bloginfo('template_url'); ?>/images/common/bnr_professional.jpg" alt="設計のプロフェッショナル プラント設計のプロフェッショナル集団です。" class="imgover" /></a></li>
<li><a href="<?php bloginfo('url'); ?>/recruit/"><img src="<?php bloginfo('template_url'); ?>/images/common/bnr_design.jpg" alt="日鐵プラント設計では、若い力を求めています。" class="imgover" /></a></li>
</ul>

<p class="inquiry"><a href="<?php bloginfo('url'); ?>/contact/"><img src="<?php bloginfo('template_url'); ?>/images/common/img_inquiry.gif" alt="お問い合わせ
資料のご請求や、事業内容などお気軽にお問い合わせ下さい。" class="imgover" /></a></p>
<!-- / id sidebar --></div>
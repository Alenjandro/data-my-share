<div class="ep_facebook"><a class="fb" title="<?php _e('Share this post on', 'amphion_lite'); ?> Facebook" href="http://facebook.com/share.php?u=<?php the_permalink() ?>&amp;amp;t=<?php echo urlencode(the_title('','', false)) ?>">Facebook</a><a class="fb_hover" title="<?php _e('Share this post on', 'amphion_lite'); ?> Facebook" href="http://facebook.com/share.php?u=<?php the_permalink() ?>&amp;amp;t=<?php echo urlencode(the_title('','', false)) ?>">facebook</a>
</div>

<div class="ep_twitter"><a class="twitt" href="http://twitter.com/home?status=Reading: <?php the_title(); ?> <?php the_permalink();?>" title="Tweet <?php _e('this post', 'amphion_lite'); ?>">Twitter</a><a class="twitt_hover" href="http://twitter.com/home?status=Reading: <?php the_title(); ?> <?php the_permalink();?>" title="Tweet <?php _e('this post', 'amphion_lite'); ?>">Twitter</a>
</div>

<div class="ep_stumble"><a class="stumble" title="Stumble <?php _e('This', 'amphion_lite'); ?>" href="http://www.stumbleupon.com/submit?url=<?php the_permalink(); ?>&title=<?php echo urlencode(the_title('','', false)) ?>">stumbleupon</a><a class="stumble_hover" title="Stumble <?php _e('This', 'amphion_lite'); ?>"  href="http://stumbleupon.com/submit?url=<?php the_permalink() ?>&title=<?php echo urlencode(the_title('','', false)) ?>">stumbleupon</a>
</div>
            
<div class="ep_delicious"><a class="delicious" title="<?php _e('Submit to', 'amphion_lite'); ?> Delicious" href="http://del.icio.us/post?url=<?php the_permalink() ?>&title=<?php echo urlencode(the_title('','', false)) ?>">del.icio.us</a><a class="delicious_hover" title="<?php _e('Submit to', 'amphion_lite'); ?> Delicious" href="http://del.icio.us/post?url=<?php the_permalink() ?>&title=<?php echo urlencode(the_title('','', false)) ?>">del.icio.us</a>
</div>

<div class="ep_delicious"><a class="gbuzz" title="<?php _e('Buzz this!', 'amphion_lite'); ?> Delicious" href="http://www.google.com/buzz/post">Buzz</a><a class="gbuzz_hover" title="<?php _e('Buzz this!', 'amphion_lite'); ?>" href="http://www.google.com/buzz/post" ></a>
</div>
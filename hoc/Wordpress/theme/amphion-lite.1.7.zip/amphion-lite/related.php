<?php
$backup = $post;
$categories = get_the_category($post->ID);
if ($categories) {
	$category_ids = array();
	foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;

	$args=array(
		'category__in' => $category_ids,
		'post__not_in' => array($post->ID),
		'showposts'=>4, // Number of related posts that will be shown.
		'caller_get_posts'=>1
	);

$my_query = new wp_query($args);
	if( $my_query->have_posts() ) {
		echo '<div class="post_top"></div><div class="post_mid"><h3>'.__('Related Posts' ,'amphion_lite').'</h3><ul>';
		while ($my_query->have_posts()) {
			$my_query->the_post();

		?>
<li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><span class="related_img"><?php amphion_lite_the_thumb('thumbnail'); ?></span></a><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></li>

		<?php
		}
	echo '</ul></div><div class="post_bottom"></div>';
	}
}
$post = $backup;
wp_reset_query(); 
?>
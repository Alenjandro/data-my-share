// EASY SLIDER SETTINGS
jQuery(function(){
	jQuery("#slider").easySlider({
		auto: true,
		continuous: true,
		pause: 2000,
		numeric: true 
	});
});


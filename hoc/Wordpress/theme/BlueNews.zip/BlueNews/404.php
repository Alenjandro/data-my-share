<?php get_header(); ?>
<div class="span-24" id="contentwrap">
    <?php get_sidebars('left'); ?>
	<div class="span-14">
		<div id="content">	
			<h2 class='pagetitle'>Error 404 - Page Not Found</h2>
		</div>
	</div>

<?php get_sidebars('right'); ?>
	</div>
<?php get_footer(); ?>


Hey, thanks for downloading my theme.
Notice: This is my first (free) WordPress theme.


Localization feature added in 1.5
Please contact me, if you like to contribute your own language.


CHANGELOG | v1.9
| Wider option (960px) via theme settings
| IE6 footer bug fix
| Comments Off bug in Opera
| Overflow:hidden bug on justified text
| Two Column categories on non-widegetized sidebar in separate file
| Custom CSS in theme settings
| Dropdown menus with one level
| Fixed Safari/Chrome comments moderation bug

CHANGELOG | v1.9.2
| Fixed z-index issues with dropdown menu
| Disqus bug fixed

CHANGELOG | V1.9.6
| Fixed lightbox problem
| Post author highlight WP2.8 fixed
| Two sidebars on Wide layout (BETA)
| Small bug fixes

CHANGELOG | V1.9.8
| Finnish translation updated, thanks to Tomi R.
| LightWord internal version check removed
| Italian translation updated
| Two columns version revised
| New Post Thumbnail Feature
| One comment per page bug fixed (wordpress.org/support/topic/357045)

CHANGELOG | 1.9.9
| Cuf�n is back, special thanks goes to Voyagerfan5761 (technobabbl.es)
| Finnish language updated (Tomi R. | rantom.fi)
| Fixes an issue that can occur when a user has magic_quotes switched to on (Steven L. | isomehowhate.com)
| Post author settings revised

CHANGELOG | 1.9.9.1
| Added Danish and Chinese (traditional) language file

CHANGELOG | 1.9.9.2
| Added Bulgarian language file (thanks to Marin D.)

CHANGELOG | 1.9.9.3
| WP-PAGENAVI plugin should work now
| Added some new admin panel fields
| Fixed stripslashes bug on theme settings fields
| Spanish language improved + some functions.php contribution by GeekRMX (ngeeks.com)
| A new Cuf�n settings option: CSS3 Font-face (modern browsers) --  Voyagerfan5761 (technobabbl.es) idea

CHANGELOG | 1.9.9.4
| Fixed: Comment reply link on pages
| Fixed: Older/previous comments link on page

CHANGELOG | 1.9.9.6
| Fixed IE7 second-sidebar problem
| Fixed Cuf�n JS error on IE
| Support for WordPress 3.0 Features like background or menus (currently in beta)
| Code refreshing, replaced deprecated functions with new, updated ones

CHANGELOG | 1.9.9.7
| Save/reset buttons produces several PHP Warning notices
| Image alignment revised
| Single page template (RSS badge issue) fix, thanks to Alin Sfetcu (sanctuary.ro)
| Additional footer content (theme settings box) fixed

CHANGELOG | V2
| Catalan language added
| Single page template WP3 Menus fixed
| WP3 Menus goes out of Beta status
| Parts of code rewritten from scratch due to WP3 deprecated functions
| WordPress Custom Header (you will have to activate it from LightWord Settings -> Custom Image Header first)

CHANGELOG | V2.0.0.3
| Theme Guidelines issues
| XHTML validation error fixed
| Comment form function validation fixed
| Deprecated functions replaced

CHANGELOG | V2.0.0.4
| Table head color readable issue
| home_url() issue with WP 2.9 fixed
| "Cannot modify header information" error fixed (captainstu72 via Twitter)

CHANGELOG | V2.0.0.4a
| Nested menus should display correctly [voyagerfan5761]

CHANGELOG | V2.0.0.4b
| Nested menus should display correctly

CHANGELOG | V2.0.0.5
| Czech language file added

CHANGELOG | V2.0.0.6
| Nested menus don't render properly issue fixed
| Added an option to disable WP3 menus
| Search form should no longer be placed too high when RSS badge is enabled (not removed)

Best regards,
Andrei Luca

</div><!--wrapper-->
<div class="clear"></div>
<div id="footer">
	<div id="footer-inside">
		<p>
			<?php _e('Copyright', 'zbench'); ?>&nbsp;&copy;&nbsp;<?php echo date("Y"); ?>&nbsp;<?php bloginfo('name'); ?>
			&nbsp;|&nbsp;Powered by <a href="http://wordpress.org/">WordPress</a> 
			&nbsp;|&nbsp;Theme <a href="http://zww.me" title="designed by zwwooooo">zBench</a>
		</p>
		<span id="back-to-top">&Delta; <a href="#nav" rel="nofollow" title="Back to top"><?php _e('Top', 'zbench'); ?></a></span>
	</div>
</div><!--footer-->
<?php wp_footer(); ?>
</body>
</html>
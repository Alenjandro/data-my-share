<?php get_header(); ?>
<div class="content">

		<h1 class="title">Not Found</h1>
		<div class="postinfo">
		</div>
		<div class="post">
			<p>Sorry, but you are looking for something that isn't here.</p>
		</div>
		<div class="postbottom">
		</div>

</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>

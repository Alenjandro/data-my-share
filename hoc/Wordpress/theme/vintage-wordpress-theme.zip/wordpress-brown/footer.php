<div id="footer">
            	<div class="copyright_usage">
                	<h3>Copyright Usage</h3>
                    	<p>The text, images and tutorials themselves<br />
                        are copyright their respective owners.</p>
                </div>
                
                <div class="tutorials">
                	<h3>Copyright Usage</h3>
                		<p>We'll give you $150 cash to boot!<br />
						<a href="#">Read More Details</a></p>
                </div>
                
                <div class="suggestions">
                	<h3>Copyright Usage</h3>
                    	<p>This is YOUR site, have feedback?<br />
                        <a href="#">Let us know!</a></p>
                </div>
                
                <p class="copyright"><span>&copy; 2008 Delliblog. Powered by Wordpress. Brought to you by <a href="http://www.smashingmagazine.com">Smashing Magazine</a>.</span><span class="right">Theme designed by <a href="http://www.dellustrations.com/work_wp.html" target="_blank">Dellustrations</a></span></p>
            </div> <!--footer ends-->
      </div> <!--main ends-->
    </div> <!--container ends-->
	</div><!--wrapper ends-->
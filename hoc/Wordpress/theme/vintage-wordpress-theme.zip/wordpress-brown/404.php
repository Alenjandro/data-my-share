<?php get_header(); ?>

	<div id="content" class="widget_6">

		<h2 class="center">Error 404 - Not Found</h2>
		<p>You have try to access to unavailable area or that page you want to access not in the host.<p>

	</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
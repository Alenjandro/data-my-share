
<div class="headbanner">

<?php 
	$hban = get_option('zm_hbanner'); 
	$hurl = get_option('zm_hurl'); 
	?>
<a href="<?php echo ($hurl); ?>" rel="bookmark" title=""><img src="<?php echo ($hban); ?>" alt="" style="vertical-align:bottom;" /></a>

</div>
<div class="clear"></div>
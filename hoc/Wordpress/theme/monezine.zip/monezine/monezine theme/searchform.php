<div id="search">
			<form method="get" id="searchform" action="<?php bloginfo('home'); ?>" >
					<input id="s" type="text" name="s" value="<?php echo wp_specialchars($s, 1); ?>" />
					<input id="searchsubmit" type="submit" value="" />
			
				</form>
				
</div>
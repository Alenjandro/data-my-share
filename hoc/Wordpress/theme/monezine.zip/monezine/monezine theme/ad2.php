


<div class="ad2"> 

<?php $ads1 = get_option('zm_ads1'); echo stripslashes($ads1); ?>

</div>
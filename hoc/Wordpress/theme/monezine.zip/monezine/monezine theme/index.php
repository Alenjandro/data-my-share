<?php get_header(); ?>

	<?php include (TEMPLATEPATH . '/glide.php'); ?>
<div class="clear"></div>

<div id="content">




<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>

<div class="single" id="post-<?php the_ID(); ?>">
<div class="title">
<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>
<div class="date"><span class="author">Posted by <?php the_author(); ?></span> <span class="clock"> On <?php the_time('F - j - Y'); ?></span>	</div>	
</div>

<div class="cover">
<div class="entry">
<?php $screen = get_post_meta($post->ID,'screen', true); ?>
<img src="<?php echo ($screen); ?>" width="160" height="100" alt=""  />
		<?php the_content_limit(600, ""); ?>
				<div class="clear"></div>
</div>

</div>

<div class="singleinfo">
	<div class="comm"><?php comments_popup_link('ADD COMMENTS', '1 COMMENT', '% COMMENTS'); ?></div>
	<div class="more"><a href="<?php the_permalink() ?>">READ MORE</a> </div>
</div>


</div>
		<?php endwhile; ?>



	<?php else : ?>

		<h1 class="title">Not Found</h1>
		<p>Sorry, but you are looking for something that isn't here.</p>

	<?php endif; ?>


</div>


<?php get_sidebar(); ?>
<?php get_footer(); ?>

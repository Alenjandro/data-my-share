
<div class="ad1"> 

<?php $ads2 = get_option('zm_ads2'); echo stripslashes($ads2); ?>

</div>
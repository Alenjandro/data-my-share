<div id="rightcol">

<?php include (TEMPLATEPATH . '/bigbanner.php'); ?>
<?php include (TEMPLATEPATH . '/tab.php'); ?>
<?php include (TEMPLATEPATH . '/sponsors.php'); ?>

<div id="sidebar">
<?php include (TEMPLATEPATH . '/sidebar2.php'); ?>
<?php include (TEMPLATEPATH . '/sidebar1.php'); ?>	
	
</div>
</div>


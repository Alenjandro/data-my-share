<div class="clear"></div>
        <div id="tabzine" class="widgets">

            <ul class="tabnav">
                <li class="pop"><a href="#popular"> POPULAR </a></li>
                <li class="fea"><a href="#archive"> ARCHIVE </a></li>
				<li class="rec"><a href=" #recent"> ACCOUNT </a></li>
            </ul>

            <div id="popular" class="tabdiv">

              <ul>
  
		 	<?php if(function_exists('akpc_most_popular')) { akpc_most_popular(); } ?>

             </ul>

            </div><!--/popular-->
            
           
            
            <div id="archive" class="tabdiv">
         	<ul>
				<?php wp_get_archives('type=monthly&limit=12'); ?>
			</ul>
            </div><!--featured-->
			
			 <div id="recent" class="tabdiv">
              
			    	
 <?php global $user_ID, $user_identity, $user_level ?>
		<?php if ( !$user_ID ) : ?>
	
		<ul>
			<li>
			<form action="<?php bloginfo('url') ?>/wp-login.php" method="post">
			<div class="form-item">
				<label for="log">  Username<br /><input type="text" name="log" id="log" value="<?php echo wp_specialchars(stripslashes($user_login), 1) ?>" size="22" /> </label><br />
		    </div>	
			
			<div class="form-item">
				<label for="pwd"> Password<br /><input type="password" name="pwd" id="pwd" size="22" /></label><br />
				
		    </div>		
				<input type="submit" name="submit" value="Submit" class="button" />
				<label for="rememberme"><input name="rememberme" id="rememberme" type="checkbox" checked="checked" value="forever" /> Remember me</label><br />
			
				<input type="hidden" name="redirect_to" value="<?php echo $_SERVER['REQUEST_URI']; ?>"/>
			</form>
			</li>

			<li><a href="<?php bloginfo('url') ?>/wp-register.php">Create new account</a></li>
			<li><a href="<?php bloginfo('url') ?>/wp-login.php?action=lostpassword">Forgot your password?</a></li>
		</ul>
	<?php else : ?>
	

	
		<ul>
			<li>Welcome <strong><?php echo $user_identity ?></strong>.	</li>
		
				<li><a href="<?php bloginfo('url') ?>/wp-admin/">Go to dashboard</a></li>

				<?php if ( $user_level >= 1 ) : ?>
				<li><a href="<?php bloginfo('url') ?>/wp-admin/post-new.php">Make new post</a></li>
				<li><a href="<?php bloginfo('url') ?>/wp-admin/page-new.php">Make new page</a></li>
				<?php endif // $user_level >= 1 ?>

				<li><a href="<?php bloginfo('url') ?>/wp-admin/profile.php">View profile</a></li>
				<li><a href="<?php bloginfo('url') ?>/wp-login.php?action=logout&amp;redirect_to=<?php echo urlencode($_SERVER['REQUEST_URI']) ?>">Logout</a></li>
		
		
		</ul>
		
	<?php endif; ?>	
            </div><!--/recent-->

        </div><!--/widget-->

<div class="bigbanner">

<?php 
	$bigban = get_option('zm_sqbanner'); 
	$bigurl = get_option('zm_squrl'); 
	?>
<a href="<?php echo ($bigurl); ?>" rel="bookmark" title=""><img src="<?php echo ($bigban); ?>" alt="" style="vertical-align:bottom;"  /></a>

</div>
<div class="clear"></div>